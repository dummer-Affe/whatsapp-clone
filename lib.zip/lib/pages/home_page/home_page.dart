import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:whatsapp_clone/models/chat/message.dart';
import 'package:whatsapp_clone/states/conversation_state.dart';
import 'package:whatsapp_clone/states/conversation_user_state.dart';

import '../../main.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool loaded = false;
  @override
  void initState() {
    appSettings.listenState(this);
    super.initState();
  }

  setup() async {
    setState(() {
      loaded = false;
    });
    conversationUserState = Get.put(ConversationUserState());
    conversationState = Get.put(ConversationState());
    await conversationState.setupConversations();
    setState(() {
      loaded = true;
    });

    Message msg = Message.document(File("asd.pdf"),
        id: "id",
        sentBy: "sentBy",
        message: "yarramın başı",
        conversationId: "conversationId");
    msg.send();

    msg.trackMessage
        ? StreamBuilder(
            stream: msg.processStream,
            builder: (context, snapshot) => Container(),
          )
        : Container();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
