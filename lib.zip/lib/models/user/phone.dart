class UserPhone {
  String number;
  String countryCode;

  UserPhone({required this.number, required this.countryCode});
}
